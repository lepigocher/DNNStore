//------------------------------------------------------------------------------
// <g�n�r� automatiquement>
//     Ce code a �t� g�n�r� par un outil.
//
//     Les modifications apport�es � ce fichier peuvent provoquer un comportement incorrect et seront perdues si
//     le code est r�g�n�r�.
// </g�n�r� automatiquement>
//------------------------------------------------------------------------------

namespace DotNetNuke.Modules.Store.Providers.Tax.DefaultTaxProvider {
    
    
    public partial class DefaultTaxCheckout {
        
        /// <summary>
        /// Contr�le lblTaxTotal.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.UserControl lblTaxTotal;
        
        /// <summary>
        /// Contr�le lblOrderTaxTotal.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblOrderTaxTotal;
    }
}
