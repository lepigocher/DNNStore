//------------------------------------------------------------------------------
// <g�n�r� automatiquement>
//     Ce code a �t� g�n�r� par un outil.
//
//     Les modifications apport�es � ce fichier peuvent provoquer un comportement incorrect et seront perdues si
//     le code est r�g�n�r�.
// </g�n�r� automatiquement>
//------------------------------------------------------------------------------

namespace DotNetNuke.Modules.Store.Providers.Address.DefaultAddressProvider {
    
    
    public partial class StoreAddress {
        
        /// <summary>
        /// Contr�le tbAddress.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tbAddress;
        
        /// <summary>
        /// Contr�le rowUserSaved.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowUserSaved;
        
        /// <summary>
        /// Contr�le plUserSaved.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plUserSaved;
        
        /// <summary>
        /// Contr�le chkUserSaved.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkUserSaved;
        
        /// <summary>
        /// Contr�le rowPrimary.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowPrimary;
        
        /// <summary>
        /// Contr�le plPrimary.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plPrimary;
        
        /// <summary>
        /// Contr�le chkPrimary.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkPrimary;
        
        /// <summary>
        /// Contr�le rowDescription.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowDescription;
        
        /// <summary>
        /// Contr�le plDescription.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plDescription;
        
        /// <summary>
        /// Contr�le txtDescription.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtDescription;
        
        /// <summary>
        /// Contr�le valDescription.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valDescription;
        
        /// <summary>
        /// Contr�le rowFirstName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowFirstName;
        
        /// <summary>
        /// Contr�le plFirstName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plFirstName;
        
        /// <summary>
        /// Contr�le txtFirstName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFirstName;
        
        /// <summary>
        /// Contr�le valFirstName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valFirstName;
        
        /// <summary>
        /// Contr�le rowLastName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowLastName;
        
        /// <summary>
        /// Contr�le plLastName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plLastName;
        
        /// <summary>
        /// Contr�le txtLastName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtLastName;
        
        /// <summary>
        /// Contr�le valLastName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valLastName;
        
        /// <summary>
        /// Contr�le rowStreet.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowStreet;
        
        /// <summary>
        /// Contr�le plStreet.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plStreet;
        
        /// <summary>
        /// Contr�le txtStreet.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtStreet;
        
        /// <summary>
        /// Contr�le valStreet.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valStreet;
        
        /// <summary>
        /// Contr�le rowUnit.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowUnit;
        
        /// <summary>
        /// Contr�le plUnit.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plUnit;
        
        /// <summary>
        /// Contr�le txtUnit.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtUnit;
        
        /// <summary>
        /// Contr�le valUnit.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valUnit;
        
        /// <summary>
        /// Contr�le rowPostal.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowPostal;
        
        /// <summary>
        /// Contr�le plPostal.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plPostal;
        
        /// <summary>
        /// Contr�le txtPostal.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtPostal;
        
        /// <summary>
        /// Contr�le valPostal.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valPostal;
        
        /// <summary>
        /// Contr�le rowCity.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowCity;
        
        /// <summary>
        /// Contr�le plCity.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plCity;
        
        /// <summary>
        /// Contr�le txtCity.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCity;
        
        /// <summary>
        /// Contr�le valCity.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valCity;
        
        /// <summary>
        /// Contr�le rowCountry.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowCountry;
        
        /// <summary>
        /// Contr�le plCountry.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plCountry;
        
        /// <summary>
        /// Contr�le cboCountry.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.WebControls.CountryListBox cboCountry;
        
        /// <summary>
        /// Contr�le valCountry.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valCountry;
        
        /// <summary>
        /// Contr�le rowRegion.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowRegion;
        
        /// <summary>
        /// Contr�le plRegion.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plRegion;
        
        /// <summary>
        /// Contr�le cboRegion.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList cboRegion;
        
        /// <summary>
        /// Contr�le txtRegion.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtRegion;
        
        /// <summary>
        /// Contr�le valRegion1.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valRegion1;
        
        /// <summary>
        /// Contr�le valRegion2.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valRegion2;
        
        /// <summary>
        /// Contr�le rowEmail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowEmail;
        
        /// <summary>
        /// Contr�le plEmail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plEmail;
        
        /// <summary>
        /// Contr�le txtEmail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtEmail;
        
        /// <summary>
        /// Contr�le valEmail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valEmail;
        
        /// <summary>
        /// Contr�le valCustEmail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CustomValidator valCustEmail;
        
        /// <summary>
        /// Contr�le rowTelephone.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowTelephone;
        
        /// <summary>
        /// Contr�le plTelephone.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plTelephone;
        
        /// <summary>
        /// Contr�le txtTelephone.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtTelephone;
        
        /// <summary>
        /// Contr�le valTelephone.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valTelephone;
        
        /// <summary>
        /// Contr�le rowCell.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow rowCell;
        
        /// <summary>
        /// Contr�le plCell.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl plCell;
        
        /// <summary>
        /// Contr�le txtCell.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCell;
        
        /// <summary>
        /// Contr�le valCell.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator valCell;
    }
}
