//------------------------------------------------------------------------------
// <g�n�r� automatiquement>
//     Ce code a �t� g�n�r� par un outil.
//
//     Les modifications apport�es � ce fichier peuvent provoquer un comportement incorrect et seront perdues si
//     le code est r�g�n�r�.
// </g�n�r� automatiquement>
//------------------------------------------------------------------------------

namespace DotNetNuke.Modules.Store.WebControls {
    
    
    public partial class CatalogSettings {
        
        /// <summary>
        /// Contr�le dshGenSettings.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshGenSettings;
        
        /// <summary>
        /// Contr�le tblGenSettings.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblGenSettings;
        
        /// <summary>
        /// Contr�le lblCatTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCatTemplate;
        
        /// <summary>
        /// Contr�le lstTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstTemplate;
        
        /// <summary>
        /// Contr�le lblUseDefaultCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblUseDefaultCategory;
        
        /// <summary>
        /// Contr�le chkUseDefaultCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkUseDefaultCategory;
        
        /// <summary>
        /// Contr�le trDefaultCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trDefaultCategory;
        
        /// <summary>
        /// Contr�le lblDefaultCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblDefaultCategory;
        
        /// <summary>
        /// Contr�le lstDefaultCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstDefaultCategory;
        
        /// <summary>
        /// Contr�le trDisplayAllProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trDisplayAllProducts;
        
        /// <summary>
        /// Contr�le lblDisplayAllProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblDisplayAllProducts;
        
        /// <summary>
        /// Contr�le chkDisplayAllProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkDisplayAllProducts;
        
        /// <summary>
        /// Contr�le lblShowCategoryMsg.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowCategoryMsg;
        
        /// <summary>
        /// Contr�le chkShowMessage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowMessage;
        
        /// <summary>
        /// Contr�le lblShowCategoryProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowCategoryProducts;
        
        /// <summary>
        /// Contr�le chkShowCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowCategory;
        
        /// <summary>
        /// Contr�le lblShowProductDetail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowProductDetail;
        
        /// <summary>
        /// Contr�le chkShowDetail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowDetail;
        
        /// <summary>
        /// Contr�le trShowAlsoBoughtProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trShowAlsoBoughtProducts;
        
        /// <summary>
        /// Contr�le lblShowAlsoBoughtProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowAlsoBoughtProducts;
        
        /// <summary>
        /// Contr�le chkShowAlsoBought.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowAlsoBought;
        
        /// <summary>
        /// Contr�le lblShowNewProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowNewProducts;
        
        /// <summary>
        /// Contr�le chkShowNew.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowNew;
        
        /// <summary>
        /// Contr�le lblShowFeaturedProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowFeaturedProducts;
        
        /// <summary>
        /// Contr�le chkShowFeatured.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowFeatured;
        
        /// <summary>
        /// Contr�le lblShowPopularProducts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblShowPopularProducts;
        
        /// <summary>
        /// Contr�le chkShowPopular.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkShowPopular;
        
        /// <summary>
        /// Contr�le lblAllowPrint.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblAllowPrint;
        
        /// <summary>
        /// Contr�le chkAllowPrint.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkAllowPrint;
        
        /// <summary>
        /// Contr�le lblEnableContentIndexing.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblEnableContentIndexing;
        
        /// <summary>
        /// Contr�le chkEnableContentIndexing.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkEnableContentIndexing;
        
        /// <summary>
        /// Contr�le lblEnableImageCaching.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblEnableImageCaching;
        
        /// <summary>
        /// Contr�le chkEnableImageCaching.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkEnableImageCaching;
        
        /// <summary>
        /// Contr�le lblCacheDuration.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCacheDuration;
        
        /// <summary>
        /// Contr�le txtCacheDuration.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCacheDuration;
        
        /// <summary>
        /// Contr�le dshCategoryProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshCategoryProductList;
        
        /// <summary>
        /// Contr�le tblCategoryProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblCategoryProductList;
        
        /// <summary>
        /// Contr�le lblCSContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSContainerTemplate;
        
        /// <summary>
        /// Contr�le lstCPLContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstCPLContainerTemplate;
        
        /// <summary>
        /// Contr�le lblCSListTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSListTemplate;
        
        /// <summary>
        /// Contr�le lstCPLTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstCPLTemplate;
        
        /// <summary>
        /// Contr�le lblCSRows.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSRows;
        
        /// <summary>
        /// Contr�le txtCPLRowCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCPLRowCount;
        
        /// <summary>
        /// Contr�le lblCSColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSColumns;
        
        /// <summary>
        /// Contr�le txtCPLColumnCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCPLColumnCount;
        
        /// <summary>
        /// Contr�le lblCSColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSColumnWidth;
        
        /// <summary>
        /// Contr�le txtCPLColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCPLColumnWidth;
        
        /// <summary>
        /// Contr�le lblCSRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSRepeatDirection;
        
        /// <summary>
        /// Contr�le lstCPLRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstCPLRepeatDirection;
        
        /// <summary>
        /// Contr�le lblCSShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSShowThumbnail;
        
        /// <summary>
        /// Contr�le chkCPLShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkCPLShowThumbnail;
        
        /// <summary>
        /// Contr�le lblCSThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSThumbnailWidth;
        
        /// <summary>
        /// Contr�le txtCPLThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCPLThumbnailWidth;
        
        /// <summary>
        /// Contr�le lblCPSGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCPSGIFBgColor;
        
        /// <summary>
        /// Contr�le txtCPLGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCPLGIFBgColor;
        
        /// <summary>
        /// Contr�le lblCSDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSDetailPage;
        
        /// <summary>
        /// Contr�le lstCPLDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstCPLDetailPage;
        
        /// <summary>
        /// Contr�le lblCSSubCategories.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSSubCategories;
        
        /// <summary>
        /// Contr�le chkCPLSubCategories.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkCPLSubCategories;
        
        /// <summary>
        /// Contr�le lblCSRepositioning.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSRepositioning;
        
        /// <summary>
        /// Contr�le chkCPLRepositioning.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkCPLRepositioning;
        
        /// <summary>
        /// Contr�le dshSearchProduct.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshSearchProduct;
        
        /// <summary>
        /// Contr�le tblSearchProduct.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblSearchProduct;
        
        /// <summary>
        /// Contr�le lblCSSearchColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSSearchColumns;
        
        /// <summary>
        /// Contr�le chkSearchManufacturer.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSearchManufacturer;
        
        /// <summary>
        /// Contr�le chkSearchModelNumber.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSearchModelNumber;
        
        /// <summary>
        /// Contr�le chkSearchModelName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSearchModelName;
        
        /// <summary>
        /// Contr�le chkSearchSummary.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSearchSummary;
        
        /// <summary>
        /// Contr�le chkSearchDescription.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSearchDescription;
        
        /// <summary>
        /// Contr�le trSearchColumn.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trSearchColumn;
        
        /// <summary>
        /// Contr�le lblSSSearchColumn.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblSSSearchColumn;
        
        /// <summary>
        /// Contr�le lstSPLSearchColumn.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstSPLSearchColumn;
        
        /// <summary>
        /// Contr�le trSearchTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trSearchTemplate;
        
        /// <summary>
        /// Contr�le lblSSListTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblSSListTemplate;
        
        /// <summary>
        /// Contr�le lstSPLTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstSPLTemplate;
        
        /// <summary>
        /// Contr�le dshSortProduct.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshSortProduct;
        
        /// <summary>
        /// Contr�le tblSortProduct.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblSortProduct;
        
        /// <summary>
        /// Contr�le lblCSSortColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSSortColumns;
        
        /// <summary>
        /// Contr�le chkSortManufacturer.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSortManufacturer;
        
        /// <summary>
        /// Contr�le chkSortModelNumber.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSortModelNumber;
        
        /// <summary>
        /// Contr�le chkSortModelName.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSortModelName;
        
        /// <summary>
        /// Contr�le chkSortUnitPrice.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSortUnitPrice;
        
        /// <summary>
        /// Contr�le chkSortCreatedDate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkSortCreatedDate;
        
        /// <summary>
        /// Contr�le trSortBy.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trSortBy;
        
        /// <summary>
        /// Contr�le lblCSSortBy.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSSortBy;
        
        /// <summary>
        /// Contr�le lstCPLSortBy.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstCPLSortBy;
        
        /// <summary>
        /// Contr�le trSortDir.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTableRow trSortDir;
        
        /// <summary>
        /// Contr�le lblCSSortDir.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCSSortDir;
        
        /// <summary>
        /// Contr�le lstCPLSortDir.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstCPLSortDir;
        
        /// <summary>
        /// Contr�le dshProductDetails.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshProductDetails;
        
        /// <summary>
        /// Contr�le tblProductDetails.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblProductDetails;
        
        /// <summary>
        /// Contr�le lblDetailTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblDetailTemplate;
        
        /// <summary>
        /// Contr�le lstDetailTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstDetailTemplate;
        
        /// <summary>
        /// Contr�le lblPDSCartWarning.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPDSCartWarning;
        
        /// <summary>
        /// Contr�le chkDetailCartWarning.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkDetailCartWarning;
        
        /// <summary>
        /// Contr�le lblPDSShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPDSShowThumbnail;
        
        /// <summary>
        /// Contr�le chkDetailShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkDetailShowThumbnail;
        
        /// <summary>
        /// Contr�le lblPDSThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPDSThumbnailWidth;
        
        /// <summary>
        /// Contr�le txtDetailThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtDetailThumbnailWidth;
        
        /// <summary>
        /// Contr�le lblPDSGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPDSGIFBgColor;
        
        /// <summary>
        /// Contr�le txtDetailGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtDetailGIFBgColor;
        
        /// <summary>
        /// Contr�le lblPDSShowReviews.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPDSShowReviews;
        
        /// <summary>
        /// Contr�le chkDetailShowReviews.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkDetailShowReviews;
        
        /// <summary>
        /// Contr�le lblPDSReturnPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPDSReturnPage;
        
        /// <summary>
        /// Contr�le lstPDSReturnPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstPDSReturnPage;
        
        /// <summary>
        /// Contr�le dshAlsoBoughtProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshAlsoBoughtProductList;
        
        /// <summary>
        /// Contr�le tblAlsoBoughtProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblAlsoBoughtProductList;
        
        /// <summary>
        /// Contr�le lblABPSContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSContainerTemplate;
        
        /// <summary>
        /// Contr�le lstABPLContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstABPLContainerTemplate;
        
        /// <summary>
        /// Contr�le lblABPSListTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSListTemplate;
        
        /// <summary>
        /// Contr�le lstABPLTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstABPLTemplate;
        
        /// <summary>
        /// Contr�le lblABPSRows.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSRows;
        
        /// <summary>
        /// Contr�le txtABPLRowCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtABPLRowCount;
        
        /// <summary>
        /// Contr�le lblABPSColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSColumns;
        
        /// <summary>
        /// Contr�le txtABPLColumnCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtABPLColumnCount;
        
        /// <summary>
        /// Contr�le lblABPSColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSColumnWidth;
        
        /// <summary>
        /// Contr�le txtABPLColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtABPLColumnWidth;
        
        /// <summary>
        /// Contr�le lblABPSRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSRepeatDirection;
        
        /// <summary>
        /// Contr�le lstABPLRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstABPLRepeatDirection;
        
        /// <summary>
        /// Contr�le lblABPSShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSShowThumbnail;
        
        /// <summary>
        /// Contr�le chkABPLShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkABPLShowThumbnail;
        
        /// <summary>
        /// Contr�le lblABPSThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSThumbnailWidth;
        
        /// <summary>
        /// Contr�le txtABPLThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtABPLThumbnailWidth;
        
        /// <summary>
        /// Contr�le lblABPSGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSGIFBgColor;
        
        /// <summary>
        /// Contr�le txtABPLGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtABPLGIFBgColor;
        
        /// <summary>
        /// Contr�le lblABPSDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblABPSDetailPage;
        
        /// <summary>
        /// Contr�le lstABPLDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstABPLDetailPage;
        
        /// <summary>
        /// Contr�le dshNewProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshNewProductList;
        
        /// <summary>
        /// Contr�le tblNewProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblNewProductList;
        
        /// <summary>
        /// Contr�le lblNPSContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSContainerTemplate;
        
        /// <summary>
        /// Contr�le lstNPLContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstNPLContainerTemplate;
        
        /// <summary>
        /// Contr�le lblNPSListTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSListTemplate;
        
        /// <summary>
        /// Contr�le lstNPLTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstNPLTemplate;
        
        /// <summary>
        /// Contr�le lblNPSRows.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSRows;
        
        /// <summary>
        /// Contr�le txtNPLRowCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtNPLRowCount;
        
        /// <summary>
        /// Contr�le lblNPSColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSColumns;
        
        /// <summary>
        /// Contr�le txtNPLColumnCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtNPLColumnCount;
        
        /// <summary>
        /// Contr�le lblNPSColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSColumnWidth;
        
        /// <summary>
        /// Contr�le txtNPLColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtNPLColumnWidth;
        
        /// <summary>
        /// Contr�le lblNPSRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSRepeatDirection;
        
        /// <summary>
        /// Contr�le lstNPLRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstNPLRepeatDirection;
        
        /// <summary>
        /// Contr�le lblNPSDisplayByCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSDisplayByCategory;
        
        /// <summary>
        /// Contr�le chkNPLDisplayByCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkNPLDisplayByCategory;
        
        /// <summary>
        /// Contr�le lblNPSShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSShowThumbnail;
        
        /// <summary>
        /// Contr�le chkNPLShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkNPLShowThumbnail;
        
        /// <summary>
        /// Contr�le lblNPSThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSThumbnailWidth;
        
        /// <summary>
        /// Contr�le txtNPLThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtNPLThumbnailWidth;
        
        /// <summary>
        /// Contr�le lblNPSGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSGIFBgColor;
        
        /// <summary>
        /// Contr�le txtNPLGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtNPLGIFBgColor;
        
        /// <summary>
        /// Contr�le lblNPSDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblNPSDetailPage;
        
        /// <summary>
        /// Contr�le lstNPLDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstNPLDetailPage;
        
        /// <summary>
        /// Contr�le dshFeaturedProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshFeaturedProductList;
        
        /// <summary>
        /// Contr�le tblFeaturedProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblFeaturedProductList;
        
        /// <summary>
        /// Contr�le lblFPSContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSContainerTemplate;
        
        /// <summary>
        /// Contr�le lstFPLContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstFPLContainerTemplate;
        
        /// <summary>
        /// Contr�le lblFPSListTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSListTemplate;
        
        /// <summary>
        /// Contr�le lstFPLTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstFPLTemplate;
        
        /// <summary>
        /// Contr�le lblFPSRows.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSRows;
        
        /// <summary>
        /// Contr�le txtFPLRowCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFPLRowCount;
        
        /// <summary>
        /// Contr�le lblFPSColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSColumns;
        
        /// <summary>
        /// Contr�le txtFPLColumnCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFPLColumnCount;
        
        /// <summary>
        /// Contr�le lblFPSColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSColumnWidth;
        
        /// <summary>
        /// Contr�le txtFPLColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFPLColumnWidth;
        
        /// <summary>
        /// Contr�le lblFPSRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSRepeatDirection;
        
        /// <summary>
        /// Contr�le lstFPLRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstFPLRepeatDirection;
        
        /// <summary>
        /// Contr�le lblFPSDisplayByCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSDisplayByCategory;
        
        /// <summary>
        /// Contr�le chkFPLDisplayByCategory.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkFPLDisplayByCategory;
        
        /// <summary>
        /// Contr�le lblFPSShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSShowThumbnail;
        
        /// <summary>
        /// Contr�le chkFPLShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkFPLShowThumbnail;
        
        /// <summary>
        /// Contr�le lblFPSThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSThumbnailWidth;
        
        /// <summary>
        /// Contr�le txtFPLThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFPLThumbnailWidth;
        
        /// <summary>
        /// Contr�le lblFPSGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSGIFBgColor;
        
        /// <summary>
        /// Contr�le txtFPLGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFPLGIFBgColor;
        
        /// <summary>
        /// Contr�le lblFPSDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblFPSDetailPage;
        
        /// <summary>
        /// Contr�le lstFPLDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstFPLDetailPage;
        
        /// <summary>
        /// Contr�le dshPopularProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.SectionHeadControl dshPopularProductList;
        
        /// <summary>
        /// Contr�le tblPopularProductList.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlTable tblPopularProductList;
        
        /// <summary>
        /// Contr�le lblPPSContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSContainerTemplate;
        
        /// <summary>
        /// Contr�le lstPPLContainerTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstPPLContainerTemplate;
        
        /// <summary>
        /// Contr�le lblPPSListTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSListTemplate;
        
        /// <summary>
        /// Contr�le lstPPLTemplate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstPPLTemplate;
        
        /// <summary>
        /// Contr�le lblPPSRows.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSRows;
        
        /// <summary>
        /// Contr�le txtPPLRowCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtPPLRowCount;
        
        /// <summary>
        /// Contr�le lblPPSColumns.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSColumns;
        
        /// <summary>
        /// Contr�le txtPPLColumnCount.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtPPLColumnCount;
        
        /// <summary>
        /// Contr�le lblPPSColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSColumnWidth;
        
        /// <summary>
        /// Contr�le txtPPLColumnWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtPPLColumnWidth;
        
        /// <summary>
        /// Contr�le lblPPSRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSRepeatDirection;
        
        /// <summary>
        /// Contr�le lstPPLRepeatDirection.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstPPLRepeatDirection;
        
        /// <summary>
        /// Contr�le lblPPSShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSShowThumbnail;
        
        /// <summary>
        /// Contr�le chkPPLShowThumbnail.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkPPLShowThumbnail;
        
        /// <summary>
        /// Contr�le lblPPSThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSThumbnailWidth;
        
        /// <summary>
        /// Contr�le txtPPLThumbnailWidth.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtPPLThumbnailWidth;
        
        /// <summary>
        /// Contr�le lblPPSGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSGIFBgColor;
        
        /// <summary>
        /// Contr�le txtPPLGIFBgColor.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtPPLGIFBgColor;
        
        /// <summary>
        /// Contr�le lblPPSDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblPPSDetailPage;
        
        /// <summary>
        /// Contr�le lstPPLDetailPage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList lstPPLDetailPage;
    }
}
