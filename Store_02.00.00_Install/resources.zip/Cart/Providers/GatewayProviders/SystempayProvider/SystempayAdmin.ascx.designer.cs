//------------------------------------------------------------------------------
// <g�n�r� automatiquement>
//     Ce code a �t� g�n�r� par un outil.
//
//     Les modifications apport�es � ce fichier peuvent provoquer un comportement incorrect et seront perdues si
//     le code est r�g�n�r�.
// </g�n�r� automatiquement>
//------------------------------------------------------------------------------

namespace DotNetNuke.Modules.Store.Cart {
    
    
    public partial class SystempayAdmin {
        
        /// <summary>
        /// Contr�le lblSiteID.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblSiteID;
        
        /// <summary>
        /// Contr�le txtSiteID.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtSiteID;
        
        /// <summary>
        /// Contr�le lblContracts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblContracts;
        
        /// <summary>
        /// Contr�le txtContracts.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtContracts;
        
        /// <summary>
        /// Contr�le lblUseTestCertificate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblUseTestCertificate;
        
        /// <summary>
        /// Contr�le chkUseTestCertificate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chkUseTestCertificate;
        
        /// <summary>
        /// Contr�le lblCertificate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCertificate;
        
        /// <summary>
        /// Contr�le txtCertificate.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCertificate;
        
        /// <summary>
        /// Contr�le lblSystempayPaymentURL.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblSystempayPaymentURL;
        
        /// <summary>
        /// Contr�le txtSystempayPaymentURL.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtSystempayPaymentURL;
        
        /// <summary>
        /// Contr�le lblSystempayLanguage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblSystempayLanguage;
        
        /// <summary>
        /// Contr�le txtSystempayLanguage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtSystempayLanguage;
        
        /// <summary>
        /// Contr�le lblCurrency.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblCurrency;
        
        /// <summary>
        /// Contr�le txtSystempayCurrency.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtSystempayCurrency;
        
        /// <summary>
        /// Contr�le lblButtonURL.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.UI.UserControls.LabelControl lblButtonURL;
        
        /// <summary>
        /// Contr�le txtButtonURL.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtButtonURL;
    }
}
