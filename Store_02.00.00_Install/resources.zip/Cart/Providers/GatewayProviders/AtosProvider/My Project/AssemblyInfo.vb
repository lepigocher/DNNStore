﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales relatives à un assembly dépendent de 
' l'ensemble d'attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Vérifiez les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("DotNetNuke.Modules.Store.AtosProvider")> 
<Assembly: AssemblyDescription("Open Source Web Application Framework")> 
<Assembly: AssemblyCompany("DNN Corp")> 
<Assembly: AssemblyProduct("http://www.dnnsoftware.com/")> 
<Assembly: AssemblyCopyright("DNN is copyright 2002-2016 by DNN Corp. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("DNN")> 

<Assembly: ComVisible(False)> 

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("3e5db550-7f0a-4477-8510-abd6e90182c4")> 

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version secondaire 
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes les valeurs ou indiquer les numéros de build et de révision par défaut 
' en utilisant '*', comme indiqué ci-dessous :

<Assembly: AssemblyVersion("3.2.1.0")> 
<Assembly: AssemblyFileVersion("3.2.1.0")> 
