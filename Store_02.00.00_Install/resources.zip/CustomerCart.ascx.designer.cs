//------------------------------------------------------------------------------
// <g�n�r� automatiquement>
//     Ce code a �t� g�n�r� par un outil.
//
//     Les modifications apport�es � ce fichier peuvent provoquer un comportement incorrect et seront perdues si
//     le code est r�g�n�r�.
// </g�n�r� automatiquement>
//------------------------------------------------------------------------------

namespace DotNetNuke.Modules.Store.WebControls {
    
    
    public partial class CustomerCart {
        
        /// <summary>
        /// Contr�le cartControl.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::DotNetNuke.Modules.Store.WebControls.CartDetail cartControl;
        
        /// <summary>
        /// Contr�le pCheckoutMessage.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl pCheckoutMessage;
        
        /// <summary>
        /// Contr�le lblCheckoutMode.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblCheckoutMode;
        
        /// <summary>
        /// Contr�le btnCheckout.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.LinkButton btnCheckout;
        
        /// <summary>
        /// Contr�le lblCheckout.
        /// </summary>
        /// <remarks>
        /// Champ g�n�r� automatiquement.
        /// Pour modifier, d�placez la d�claration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblCheckout;
    }
}
